# 十章差分
灯匠纪蓉生收到了寿面，托米行送亲笔鱼嘴收据。小徒亲见季归还孩子一盏坏灯。纪的孕女是做灯板者，请季明早两船河心并靠相见，先同物主商量能否揭板。
正文 chapters/chapter-010/draft-humanized.md
SHA-256 07ddb5086e1b308bd5d83bdc3393818cba3b0baf2391dc34b6c5980ed3c799f7
