# 三十五章差分
初十一落日前，确认‘老四’留在北，南岸向北泥弯的沉絮船座榫与带双斜角木销相合。吊胆签载十月二十七借礁号，第二班查明；木销归巴续。只点两处灯却看到三点亮。
正文 chapters/chapter-035/draft-humanized.md
SHA-256 ae768a483519e3f7d1c533a97510ebb34dd1820be60da1a697b620e48ecc59ef
