# 十四章差分
旧案脚钱三十一实付，余春迟在见证下领，以七文还亡夫詹禄十三年前的面债，伍找二十四文，新面另作请客。春迟送孔豆作季三日工钱，担保单可烧。隐雪自刻‘见纸’章。其他脚工持凭聚会门外。
正文 chapters/chapter-014/draft-humanized.md
SHA-256 997b686ebe192a1d24dda1928a4f8defce38cad4218dffa6c5e7028c78cd7f03
