# 二十章差分
初八夜。何青七灯为戏筏照路，得六夜私人油钱及零散订，最小灯工收现钱。尚有三夜公用灯油待核。唐斐以两日工雇季重装桥局硬壳卷，配对存根在北冬仓灰屋，壳上倒七再现。
正文 chapters/chapter-020/draft-humanized.md
SHA-256 6ffb0cef0b0f5487233fa6ca70e68b485b965d20a5c34980320e4f0a0e6dcfe7
