# 角色索引
CHAR-01 季杼（profiles/季杼.md），补书铺。CHAR-02 余禄娘（profiles/余禄娘.md），渡妇，认识幼年季杼。CHAR-03 唐斐（profiles/唐斐.md），复数，管桥局和脚会的往来。CHAR-04 阿礁（profiles/阿礁.md），北岸船师。CHAR-05 王隐雪（profiles/王隐雪.md），隔壁字坊学徒，与季杼各自算工钱。
